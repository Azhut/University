class Location:
    def __init__(self, latitude, longitude, country, city):
        self.latitude = latitude
        self.longitude = longitude
        self.country = country
        self.city = city